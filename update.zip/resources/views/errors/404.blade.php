@extends('layouts.user')
@section('css')
@endsection
@section('content')
<div class="container">
  <div class="row">
    <div class="col-xl-12">
      <section id="not-found" class="center py-4 m-0">
        <h2>404 <i class="icon-line-awesome-question-circle"></i></h2>
        <p>We're sorry, but the page you were looking for doesn't exist</p>
      </section>
    </div>
  </div>
</div>
@endsection
@section('js')
@endsection
