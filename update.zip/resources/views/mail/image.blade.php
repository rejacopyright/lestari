<div style="display: -webkit-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap;-ms-align-items: center;align-items: center;background-color: #fff;z-index: 999;">
  <div style="width: 100%;-webkit-box-sizing: border-box;box-sizing: border-box;position: relative;-webkit-flex: 0;-ms-flex: 0 0 100%;flex: 0 0 100%;text-align: center;">
    <img src="{{url('public/images/banner')}}/{{$image->image}}" alt="" style="width: 100%;">
  </div>
</div>
