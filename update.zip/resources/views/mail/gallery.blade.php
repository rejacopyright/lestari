<div style="padding: 1rem 10%;display: -webkit-box; display: -ms-flexbox; display: flex; -ms-flex-wrap: wrap; flex-wrap: wrap;-ms-align-items: center;align-items: center;background-color: #fff;">
  <?php for ($i=0; $i < 4; $i++): ?>
    <div style="padding: .5rem;width:50%;-webkit-box-sizing: border-box;box-sizing: border-box;position: relative;-webkit-flex: 0;-ms-flex: 0 0 50%;flex: 0 0 50%;text-align: center;">
      <div style="padding-top: 100%;background: url({{url('public')}}/images/samples/promo-5.jpg) no-repeat center center;-webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;"></div>
    </div>
  <?php endfor; ?>
</div>
