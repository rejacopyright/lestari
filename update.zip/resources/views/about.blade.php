@extends('layouts.user')
@section('title') ABOUT @endsection
@section('css')
@endsection
@section('content')
<div class="single-page-header freelancer-header mb-4 py-3" data-background-image="{{url('public')}}/images/banner/{{App\banner::first()->image}}">
  <div class="container">
    <div class="col-12">
      <div class="single-page-header-inner">
        <div class="left-side">
          <div class="header-image freelancer-avatar p-3"><img src="{{url('public')}}/images/logo.png" alt=""></div>
          <div class="header-details">
            <h3>{{strtoupper($setting->name)}} <span class="text-info font-16 bold">{{ucwords($setting->description)}}</span></h3>
            <div class="freelancer-socials">
              <ul>
                <li><a href="{{$setting->facebook ?? 'javascript:void(0)'}}" target="{{$setting->facebook ? '_blank' : '_self'}}" title="Facebook" data-tippy-placement="top"><i class="icon-brand-facebook"></i></a></li>
                <li><a href="{{$setting->twitter ?? 'javascript:void(0)'}}" target="{{$setting->twitter ? '_blank' : '_self'}}" title="Twitter" data-tippy-placement="top"><i class="icon-brand-twitter"></i></a></li>
                <li><a href="{{$setting->instagram ?? 'javascript:void(0)'}}" target="{{$setting->instagram ? '_blank' : '_self'}}" title="Instagram" data-tippy-placement="top"><i class="icon-brand-instagram"></i></a></li>
                <li><a href="{{$setting->youtube ?? 'javascript:void(0)'}}" target="{{$setting->youtube ? '_blank' : '_self'}}" title="Youtube" data-tippy-placement="top"><i class="icon-brand-youtube"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="container mt-3">
  <div class="row">
    <div class="col-lg-9 text-dark">
      <h2 class="mb-3 bg-gray py-2 px-3">About Us</h2>
      {!! $setting->about !!}
    </div>
    <div class="col-lg-3">
      <div class="accordion js-accordion">
				<div class="accordion__item js-accordion-item active">
					<div class="accordion-header js-accordion-header">VISION</div>
					<div class="accordion-body js-accordion-body">
						<div class="accordion-body__contents lh-12 text-dark">
              {!! $setting->vision !!}
						</div>
					</div>
				</div>
				<div class="accordion__item js-accordion-item">
					<div class="accordion-header js-accordion-header">MISSION</div>
					<div class="accordion-body js-accordion-body">
						<div class="accordion-body__contents lh-12 text-dark">
              {!! $setting->mission !!}
						</div>
					</div>
				</div>
			</div>
      <!-- <div class="sidebar-widget mt-4">
        <h3>Attachments</h3>
        <div class="attachments-container">
          <a href="#" class="attachment-box ripple-effect"><span>Legal</span><i>PDF</i></a>
          <a href="#" class="attachment-box ripple-effect"><span>Formal</span><i>DOCX</i></a>
        </div>
      </div> -->
    </div>
  </div>
</div>
@endsection
@section('js')
<script type="text/javascript">
  $(document).ready(function() {
    $("#navigation").find('.current').removeClass('current');
    $("#navigation").find('li a[href="{{url("about")}}"]:first').addClass('current');
  });
</script>
@endsection
