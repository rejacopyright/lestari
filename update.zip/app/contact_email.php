<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class contact_email extends Model
{
  protected $table = "contact_email";
  protected $guarded = [];
}
